from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import secrets
import threading
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from typing import Literal, Optional

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config, db, downloader

AUTH_COOKIE, UID_COOKIE, AUTH_TTL = "auth", "uid", 7 * 86400


# ---------- cycle de vie ----------
def _janitor():
    while True:
        try:
            downloader.cleanup_expired()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(600)


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init()
    threading.Thread(target=_janitor, daemon=True).start()
    yield


app = FastAPI(title="YT-DLP Web", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)


# ---------- middlewares : identifiant anonyme + en-têtes de sécurité ----------
@app.middleware("http")
async def base_middleware(request: Request, call_next):
    uid = request.cookies.get(UID_COOKIE)
    new_uid = not uid or len(uid) != 32
    if new_uid:
        uid = secrets.token_hex(16)
    request.state.uid = uid
    response = await call_next(request)
    if new_uid:
        response.set_cookie(UID_COOKIE, uid, max_age=365 * 86400, httponly=True,
                            samesite="lax", secure=request.url.scheme == "https")
    response.headers.update({
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
        "Content-Security-Policy": ("default-src 'self'; img-src 'self' https: data:; "
                                    "frame-ancestors 'none'; base-uri 'none'; form-action 'self'"),
    })
    return response


# ---------- authentification (mot de passe unique optionnel) ----------
def _sign(expiry: int) -> str:
    mac = hmac.new(config.SECRET_KEY.encode(), str(expiry).encode(), hashlib.sha256).hexdigest()
    return f"{expiry}.{mac}"


def _valid(token: str | None) -> bool:
    if not token or "." not in token:
        return False
    exp, _, _mac = token.partition(".")
    return exp.isdigit() and int(exp) > time.time() and hmac.compare_digest(_sign(int(exp)), token)


def require_auth(request: Request):
    if config.APP_PASSWORD and not _valid(request.cookies.get(AUTH_COOKIE)):
        raise HTTPException(401, "Authentification requise.")


# ---------- limitation de débit ----------
_hits: dict[str, deque] = defaultdict(deque)
_hits_lock = threading.Lock()


def rate_limit(limit: int):
    def dep(request: Request):
        key = f"{request.client.host if request.client else '?'}:{request.url.path}"
        now = time.time()
        with _hits_lock:
            q = _hits[key]
            while q and q[0] < now - 60:
                q.popleft()
            if len(q) >= limit:
                raise HTTPException(429, "Trop de requêtes, réessayez dans une minute.")
            q.append(now)
    return dep


# ---------- modèles ----------
class UrlIn(BaseModel):
    url: str = Field(max_length=2048)
    playlist: bool = False


class JobIn(BaseModel):
    url: str = Field(max_length=2048)
    mode: Literal["video", "audio"] = "video"
    quality: str = Field("best", pattern=r"^(best|\d{3,4})$")
    container: Literal["mp4", "mkv", "webm"] = "mp4"
    audio_format: Literal["mp3", "m4a", "opus", "aac", "flac", "wav"] = "mp3"
    audio_bitrate: Literal["best", "128", "192", "256", "320"] = "best"
    subtitles: bool = False
    sub_langs: str = Field("fr,en", pattern=r"^[A-Za-z0-9,\-\.\*]{1,60}$")
    embed_thumbnail: bool = True
    sponsorblock: bool = False
    playlist: bool = False
    playlist_items: Optional[str] = Field(None, pattern=r"^[0-9,\-:]{1,40}$")


class LoginIn(BaseModel):
    password: str = Field(max_length=200)


# ---------- routes publiques ----------
@app.get("/healthz")
def healthz():
    return {"ok": True}


public = APIRouter(prefix="/api")


@public.get("/session")
def session(request: Request):
    required = bool(config.APP_PASSWORD)
    return {"auth_required": required,
            "authenticated": (not required) or _valid(request.cookies.get(AUTH_COOKIE)),
            "ttl_hours": config.FILE_TTL_HOURS,
            "max_playlist_items": config.MAX_PLAYLIST_ITEMS}


@public.post("/login", dependencies=[Depends(rate_limit(10))])
def login(body: LoginIn, request: Request):
    if not config.APP_PASSWORD or not hmac.compare_digest(body.password, config.APP_PASSWORD):
        raise HTTPException(401, "Mot de passe incorrect.")
    resp = JSONResponse({"ok": True})
    resp.set_cookie(AUTH_COOKIE, _sign(int(time.time()) + AUTH_TTL), max_age=AUTH_TTL,
                    httponly=True, samesite="lax", secure=request.url.scheme == "https")
    return resp


@public.post("/logout")
def logout():
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(AUTH_COOKIE)
    return resp


# ---------- routes protégées ----------
api = APIRouter(prefix="/api", dependencies=[Depends(require_auth)])


def _view(job: dict) -> dict:
    job = dict(job)
    job.pop("owner", None)
    job["options"] = json.loads(job["options"]) if job.get("options") else {}
    job["download_url"] = f"/api/jobs/{job['id']}/file" if job["status"] == "done" else None
    return job


@api.post("/info", dependencies=[Depends(rate_limit(config.RATE_LIMIT_PER_MIN))])
async def info(body: UrlIn):
    try:
        url = await run_in_threadpool(downloader.validate_url, body.url)
        return await run_in_threadpool(downloader.extract_info, url, body.playlist)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001
        msg = downloader._ANSI.sub("", str(e)).replace("ERROR: ", "")[:400]
        raise HTTPException(422, msg or "Impossible d'analyser cette URL.")


@api.post("/jobs", status_code=201, dependencies=[Depends(rate_limit(config.RATE_LIMIT_PER_MIN))])
async def create_job(body: JobIn, request: Request):
    uid = request.state.uid
    try:
        url = await run_in_threadpool(downloader.validate_url, body.url)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if await run_in_threadpool(db.count_active, uid) >= config.MAX_JOBS_PER_USER:
        raise HTTPException(429, "Trop de téléchargements en cours.")
    params = body.model_dump()
    job_id = secrets.token_urlsafe(12)
    await run_in_threadpool(db.create_job, job_id, uid, url, body.mode, json.dumps(params))
    downloader.submit(job_id, url, params)
    return _view(await run_in_threadpool(db.get, job_id))


@api.get("/jobs")
def list_jobs(request: Request):
    return [_view(j) for j in db.list_jobs(request.state.uid)]


def _own(job_id: str, request: Request) -> dict:
    job = db.get(job_id, request.state.uid)
    if not job:
        raise HTTPException(404, "Introuvable.")
    return job


@api.post("/jobs/{job_id}/cancel")
def cancel_job(job_id: str, request: Request):
    job = _own(job_id, request)
    if job["status"] in db.ACTIVE:
        downloader.cancel(job_id)
        db.update(job_id, status="cancelled", speed=None, eta=None, finished_at=time.time())
    return {"ok": True}


@api.delete("/jobs/{job_id}")
def delete_job(job_id: str, request: Request):
    job = _own(job_id, request)
    if job["status"] in db.ACTIVE:
        raise HTTPException(409, "Annulez d'abord le téléchargement.")
    downloader.remove_files(job_id)
    db.delete(job_id)
    return {"ok": True}


@api.delete("/jobs")
def clear_history(request: Request):
    for jid in db.finished_ids(request.state.uid):
        downloader.remove_files(jid)
        db.delete(jid)
    return {"ok": True}


@api.get("/jobs/{job_id}/file")
def get_file(job_id: str, request: Request):
    job = _own(job_id, request)
    if job["status"] != "done" or not job["filename"]:
        raise HTTPException(409, "Fichier non disponible.")
    base = (config.DOWNLOAD_DIR / job_id).resolve()
    path = (base / job["filename"]).resolve()
    if base not in path.parents or not path.is_file():
        raise HTTPException(404, "Le fichier a expiré.")
    return FileResponse(path, filename=path.name, media_type="application/octet-stream")


@api.get("/events")
async def events(request: Request):
    uid = request.state.uid

    async def gen():
        last, idle = None, 0
        while not await request.is_disconnected():
            jobs = [_view(j) for j in await run_in_threadpool(db.list_jobs, uid)]
            payload = json.dumps(jobs)
            if payload != last:
                last, idle = payload, 0
                yield f"data: {payload}\n\n"
            else:
                idle += 1
                if idle % 15 == 0:
                    yield ": ping\n\n"
            await asyncio.sleep(1)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


app.include_router(public)
app.include_router(api)
app.mount("/", StaticFiles(directory=str(__import__("pathlib").Path(__file__).parent / "static"), html=True), name="static")
