# YT-DLP Web

Version web de l'exécutable `yt-dlp-2026.10.26.exe` : le site s'appuie sur la **bibliothèque Python officielle yt-dlp**
(le .exe n'est qu'un empaquetage PyInstaller de celle-ci), pilotée par une API FastAPI et une interface responsive.

## Fonctionnalités
- Analyse d'URL (titre, miniature, durée, qualités et sous-titres disponibles), vidéos et playlists
- Vidéo : qualité max choisie, conteneur MP4 / MKV / WebM, sous-titres intégrés, miniature et métadonnées intégrées
- Audio : MP3, M4A, Opus, AAC, FLAC, WAV, débit au choix
- SponsorBlock, sélection d'éléments de playlist (`1-5,8`), plusieurs fichiers livrés en ZIP
- File d'attente, progression/vitesse/ETA en temps réel (SSE), annulation, historique par navigateur
- Mot de passe optionnel, limitation de débit, nettoyage automatique des fichiers, thème clair/sombre

## Lancer en local (sans Docker)
Prérequis : Python 3.10+, `ffmpeg` et `deno` dans le PATH.
```bash
python -m venv .venv && source .venv/bin/activate      # Windows : .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Ouvrir http://127.0.0.1:8000

## Mise en ligne (VPS + Docker, HTTPS automatique)
1. Louez un VPS Linux (2 Go de RAM conseillés), installez Docker, pointez un enregistrement DNS `A` de votre domaine vers son IP.
2. Copiez ce dossier sur le serveur, puis : `cp .env.example .env` et renseignez `DOMAIN`, `APP_PASSWORD`, `SECRET_KEY`.
3. `docker compose up -d --build` — Caddy obtient le certificat HTTPS tout seul.
4. Le site est disponible sur `https://votre-domaine`.

**Mises à jour** : yt-dlp suit les changements des sites ; reconstruisez régulièrement
(`docker compose build --no-cache app && docker compose up -d`), idéalement via une tâche cron hebdomadaire.
**Sauvegarde** : le volume `data` contient la base SQLite et les fichiers temporaires.

## Sécurité mise en place
Mot de passe + cookie signé HMAC, cookies HttpOnly/SameSite, rejet des URL vers réseaux privés (SSRF), options yt-dlp en liste blanche
(aucun argument libre, pas d'exécution de commande), validation stricte des entrées, limitation de débit, quotas par utilisateur,
en-têtes CSP/nosniff/X-Frame, conteneur non-root en lecture seule, accès aux fichiers cloisonné par utilisateur.

## Limites à connaître
- L'exécutable d'origine est la ligne de commande yt-dlp : il n'avait **pas d'interface graphique** ; design, thème et animations sont donc créés ici.
- Seules les options courantes sont exposées. Les centaines d'options avancées (cookies, proxy, post-traitements personnalisés…) sont volontairement
  non ouvertes sur un site public ; elles peuvent s'ajouter dans `build_argv()` (`app/downloader.py`).
- Les sites qui exigent une connexion nécessitent des cookies : non pris en charge ici.
- Le contrôle anti-SSRF vérifie la résolution DNS avant l'appel ; pour une protection totale, ajoutez un filtrage réseau sortant au niveau du pare-feu.
- Utilisez le site uniquement pour des contenus dont vous avez le droit de faire une copie : l'hébergeur d'un service public est responsable de son usage
  et les conditions d'utilisation de plateformes comme YouTube interdisent souvent le téléchargement.
