import sqlite3
import threading
import time

from . import config

_lock = threading.Lock()
_db: sqlite3.Connection | None = None

COLUMNS = {
    "title", "status", "progress", "speed", "eta", "filename", "filesize",
    "error", "started_at", "finished_at",
}
PUBLIC = ("id", "url", "title", "mode", "options", "status", "progress", "speed",
          "eta", "filename", "filesize", "error", "created_at", "finished_at")
ACTIVE = ("queued", "running", "processing")


def init() -> None:
    global _db
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    _db = sqlite3.connect(config.DB_PATH, check_same_thread=False, timeout=30)
    _db.row_factory = sqlite3.Row
    _db.execute("PRAGMA journal_mode=WAL")
    _db.execute(
        """CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY, owner TEXT NOT NULL, url TEXT NOT NULL,
            title TEXT, mode TEXT NOT NULL, options TEXT,
            status TEXT NOT NULL DEFAULT 'queued',
            progress REAL DEFAULT 0, speed REAL, eta REAL,
            filename TEXT, filesize INTEGER, error TEXT,
            created_at REAL NOT NULL, started_at REAL, finished_at REAL)"""
    )
    _db.execute("CREATE INDEX IF NOT EXISTS idx_jobs_owner ON jobs(owner, created_at)")
    # tâches interrompues par un redémarrage
    _db.execute(
        "UPDATE jobs SET status='failed', error='Interrompu par un redémarrage du serveur', finished_at=? "
        "WHERE status IN ('queued','running','processing')", (time.time(),))
    _db.commit()


def create_job(job_id, owner, url, mode, options_json):
    with _lock:
        _db.execute(
            "INSERT INTO jobs (id, owner, url, mode, options, created_at) VALUES (?,?,?,?,?,?)",
            (job_id, owner, url, mode, options_json, time.time()))
        _db.commit()


def update(job_id, **fields):
    fields = {k: v for k, v in fields.items() if k in COLUMNS}
    if not fields:
        return
    sets = ", ".join(f"{k}=?" for k in fields)
    with _lock:
        _db.execute(f"UPDATE jobs SET {sets} WHERE id=?", (*fields.values(), job_id))
        _db.commit()


def get(job_id, owner=None):
    q, args = "SELECT * FROM jobs WHERE id=?", [job_id]
    if owner is not None:
        q += " AND owner=?"
        args.append(owner)
    with _lock:
        row = _db.execute(q, args).fetchone()
    return dict(row) if row else None


def list_jobs(owner, limit=100):
    cols = ", ".join(PUBLIC)
    with _lock:
        rows = _db.execute(
            f"SELECT {cols} FROM jobs WHERE owner=? ORDER BY created_at DESC LIMIT ?",
            (owner, limit)).fetchall()
    return [dict(r) for r in rows]


def count_active(owner):
    marks = ",".join("?" * len(ACTIVE))
    with _lock:
        return _db.execute(
            f"SELECT COUNT(*) FROM jobs WHERE owner=? AND status IN ({marks})",
            (owner, *ACTIVE)).fetchone()[0]


def delete(job_id):
    with _lock:
        _db.execute("DELETE FROM jobs WHERE id=?", (job_id,))
        _db.commit()


def finished_before(cutoff):
    with _lock:
        rows = _db.execute(
            "SELECT id FROM jobs WHERE status NOT IN ('queued','running','processing') "
            "AND COALESCE(finished_at, created_at) < ?", (cutoff,)).fetchall()
    return [r["id"] for r in rows]


def finished_ids(owner):
    with _lock:
        rows = _db.execute(
            "SELECT id FROM jobs WHERE owner=? AND status NOT IN ('queued','running','processing')",
            (owner,)).fetchall()
    return [r["id"] for r in rows]
