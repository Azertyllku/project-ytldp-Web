"use strict";
const $ = (id) => document.getElementById(id);
const state = { mode: "video", info: null, es: null, ttl: 24 };

function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") n.className = v; else if (k === "text") n.textContent = v;
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v); else n.setAttribute(k, v);
  }
  kids.forEach((c) => c && n.append(c));
  return n;
}
function toast(msg, error = false) {
  const t = $("toast"); t.textContent = msg; t.className = "toast" + (error ? " error" : ""); t.hidden = false;
  clearTimeout(toast._t); toast._t = setTimeout(() => (t.hidden = true), 4500);
}
async function api(path, opts = {}) {
  const res = await fetch(path, { credentials: "same-origin", ...opts,
    headers: opts.body ? { "Content-Type": "application/json" } : undefined });
  if (res.status === 401 && path !== "/api/login") { showLogin(); throw new Error("Connexion requise."); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const d = data.detail;
    throw new Error(typeof d === "string" ? d : "Paramètres invalides.");
  }
  return data;
}
const fmtBytes = (b) => { if (!b) return "—"; const u = ["o","Ko","Mo","Go"]; let i = 0;
  while (b >= 1024 && i < 3) { b /= 1024; i++; } return b.toFixed(i ? 1 : 0) + " " + u[i]; };
const fmtDur = (s) => { if (!s) return ""; s = Math.round(s); const h = Math.floor(s / 3600),
  m = Math.floor((s % 3600) / 60), r = s % 60; const p = (n) => String(n).padStart(2, "0");
  return h ? `${h}:${p(m)}:${p(r)}` : `${m}:${p(r)}`; };
const LABELS = { queued: "En attente", running: "Téléchargement", processing: "Conversion",
  done: "Terminé", failed: "Échec", cancelled: "Annulé" };

/* ---------- thème ---------- */
const root = document.documentElement;
if (localStorage.getItem("theme")) root.dataset.theme = localStorage.getItem("theme");
$("themeBtn").onclick = () => {
  const dark = (root.dataset.theme || (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark")) === "dark";
  root.dataset.theme = dark ? "light" : "dark"; localStorage.setItem("theme", root.dataset.theme);
};

/* ---------- session ---------- */
function showLogin() { $("loginView").hidden = false; $("appView").hidden = true; $("logoutBtn").hidden = true;
  if (state.es) { state.es.close(); state.es = null; } }
function showApp(authRequired) { $("loginView").hidden = true; $("appView").hidden = false;
  $("logoutBtn").hidden = !authRequired; connect(); }

$("loginForm").onsubmit = async (e) => {
  e.preventDefault();
  try { await api("/api/login", { method: "POST", body: JSON.stringify({ password: $("password").value }) });
    $("password").value = ""; init(); } catch (err) { toast(err.message, true); }
};
$("logoutBtn").onclick = async () => { await api("/api/logout", { method: "POST" }); showLogin(); };

/* ---------- analyse ---------- */
$("urlForm").onsubmit = async (e) => {
  e.preventDefault();
  const btn = $("analyzeBtn"); btn.disabled = true; btn.textContent = "Analyse…";
  try {
    const info = await api("/api/info", { method: "POST",
      body: JSON.stringify({ url: $("url").value.trim(), playlist: $("playlistChk").checked }) });
    state.info = info; renderInfo(info);
  } catch (err) { toast(err.message, true); }
  finally { btn.disabled = false; btn.textContent = "Analyser"; }
};

function renderInfo(info) {
  $("optionsCard").hidden = false;
  $("pTitle").textContent = info.title;
  const parts = [info.uploader, fmtDur(info.duration), info.is_playlist ? `${info.playlist_count} éléments` : ""];
  $("pSub").textContent = parts.filter(Boolean).join(" · ");
  const img = $("thumb"); if (info.thumbnail) { img.src = info.thumbnail; img.hidden = false; } else img.hidden = true;
  const q = $("quality"); q.replaceChildren(el("option", { value: "best", text: "Meilleure qualité" }));
  info.heights.forEach((h) => q.append(el("option", { value: String(h), text: h + "p" })));
  $("plField").hidden = !info.is_playlist;
  $("optionsCard").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

/* ---------- options ---------- */
document.querySelectorAll(".tab").forEach((b) => b.onclick = () => {
  state.mode = b.dataset.mode;
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t === b));
  document.querySelectorAll("[data-for]").forEach((f) => f.hidden = f.dataset.for !== state.mode);
  $("subsField").hidden = state.mode !== "video" || !$("subsChk").checked;
});
$("subsChk").onchange = () => ($("subsField").hidden = !$("subsChk").checked);

$("startBtn").onclick = async () => {
  const btn = $("startBtn"); btn.disabled = true;
  const body = {
    url: $("url").value.trim(), mode: state.mode, quality: $("quality").value || "best",
    container: $("container").value, audio_format: $("aformat").value, audio_bitrate: $("abitrate").value,
    subtitles: state.mode === "video" && $("subsChk").checked, sub_langs: $("subLangs").value.trim() || "fr,en",
    embed_thumbnail: $("thumbChk").checked, sponsorblock: $("sbChk").checked,
    playlist: !!(state.info && state.info.is_playlist), playlist_items: $("plItems").value.trim() || null,
  };
  try { await api("/api/jobs", { method: "POST", body: JSON.stringify(body) });
    toast("Téléchargement ajouté à la file."); }
  catch (err) { toast(err.message, true); }
  finally { btn.disabled = false; }
};

/* ---------- liste des tâches (SSE) ---------- */
function connect() {
  if (state.es) return;
  const es = new EventSource("/api/events"); state.es = es;
  es.onmessage = (m) => renderJobs(JSON.parse(m.data));
  es.onerror = async () => { es.close(); state.es = null;
    try { const s = await api("/api/session"); if (s.authenticated) setTimeout(connect, 2000); else showLogin(); }
    catch { setTimeout(connect, 4000); } };
}

function renderJobs(jobs) {
  const ul = $("jobs"); ul.replaceChildren();
  $("empty").hidden = jobs.length > 0; $("clearBtn").hidden = jobs.length === 0;
  for (const j of jobs) {
    const active = ["queued", "running", "processing"].includes(j.status);
    const bar = el("div", { class: "bar" + (j.status === "processing" || j.status === "queued" ? " indeterminate" : "") },
      el("i"));
    bar.firstChild.style.width = (j.progress || 0) + "%";
    const meta = el("div", { class: "job-meta" },
      el("span", { text: j.status === "done" ? fmtBytes(j.filesize) : `${Math.round(j.progress || 0)} %` }),
      el("span", { text: active && j.speed ? `${fmtBytes(j.speed)}/s${j.eta ? " · " + fmtDur(j.eta) : ""}` : "" }));
    const actions = el("div", { class: "job-actions" });
    if (j.download_url) actions.append(el("a", { class: "btn primary small", href: j.download_url, download: "",
      style: "display:inline-grid;place-items:center;text-decoration:none", text: "Enregistrer" }));
    if (active) actions.append(el("button", { class: "btn ghost small", type: "button", text: "Annuler",
      onclick: () => api(`/api/jobs/${j.id}/cancel`, { method: "POST" }).catch((e) => toast(e.message, true)) }));
    else actions.append(el("button", { class: "btn ghost small", type: "button", text: "Supprimer",
      onclick: () => api(`/api/jobs/${j.id}`, { method: "DELETE" }).catch((e) => toast(e.message, true)) }));
    ul.append(el("li", { class: "job" },
      el("div", { class: "job-top" },
        el("div", { class: "job-title", text: j.title || j.url }),
        el("span", { class: "badge " + j.status, text: LABELS[j.status] || j.status })),
      active || j.status === "done" ? bar : null, active || j.status === "done" ? meta : null,
      j.error ? el("div", { class: "err", text: j.error }) : null, actions));
  }
}
$("clearBtn").onclick = () => api("/api/jobs", { method: "DELETE" }).catch((e) => toast(e.message, true));

/* ---------- démarrage ---------- */
async function init() {
  try {
    const s = await api("/api/session");
    $("ttlNote").textContent = `Les fichiers sont supprimés automatiquement après ${s.ttl_hours} h.`;
    if (s.authenticated) showApp(s.auth_required); else showLogin();
  } catch (e) { toast(e.message, true); }
}
init();
