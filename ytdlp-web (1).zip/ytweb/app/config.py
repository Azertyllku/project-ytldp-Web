import os
from pathlib import Path

DATA_DIR = Path(os.getenv("DATA_DIR", "./data")).resolve()
DOWNLOAD_DIR = DATA_DIR / "downloads"
DB_PATH = DATA_DIR / "app.db"

# Mot de passe d'accès au site (vide = accès libre, déconseillé en ligne)
APP_PASSWORD = os.getenv("APP_PASSWORD", "")
SECRET_KEY = os.getenv("SECRET_KEY", "")  # obligatoire si APP_PASSWORD est défini

MAX_CONCURRENT = int(os.getenv("MAX_CONCURRENT", "2"))        # téléchargements simultanés
MAX_JOBS_PER_USER = int(os.getenv("MAX_JOBS_PER_USER", "10"))  # tâches actives par navigateur
FILE_TTL_HOURS = float(os.getenv("FILE_TTL_HOURS", "24"))     # durée de conservation des fichiers
RATE_LIMIT_PER_MIN = int(os.getenv("RATE_LIMIT_PER_MIN", "30"))
MAX_PLAYLIST_ITEMS = int(os.getenv("MAX_PLAYLIST_ITEMS", "50"))
MAX_FILESIZE = os.getenv("MAX_FILESIZE", "2G")                 # "" = illimité
# Fichier cookies.txt (format Netscape) optionnel : utile si YouTube demande une connexion anti-bot
COOKIES_FILE = os.getenv("COOKIES_FILE", "")

if APP_PASSWORD and len(SECRET_KEY) < 16:
    raise SystemExit("SECRET_KEY (16+ caractères) est requis quand APP_PASSWORD est défini.")
