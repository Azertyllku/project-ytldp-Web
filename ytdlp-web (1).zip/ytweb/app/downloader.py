"""Couche d'accès à yt-dlp (bibliothèque Python officielle).

Les options sont construites sous forme d'arguments de ligne de commande puis
traduites par yt_dlp.parse_options : on garde ainsi exactement la logique et
l'ordre des post-processeurs de l'exécutable d'origine.
"""
import ipaddress
import re
import shutil
import socket
import threading
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

from yt_dlp import YoutubeDL, parse_options
from yt_dlp.utils import DownloadCancelled, MaxDownloadsReached

from . import config, db

_executor = ThreadPoolExecutor(max_workers=config.MAX_CONCURRENT, thread_name_prefix="dl")
_cancel_flags: dict[str, threading.Event] = {}
_ANSI = re.compile(r"\x1b\[[0-9;]*m")


# ---------- sécurité ----------
def validate_url(url: str) -> str:
    url = url.strip()
    p = urlparse(url)
    if len(url) > 2048 or p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("URL invalide (http ou https uniquement).")
    try:
        infos = socket.getaddrinfo(p.hostname, None)
    except socket.gaierror:
        raise ValueError("Nom de domaine introuvable.")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if ip.version == 6 and ip.ipv4_mapped:
            ip = ip.ipv4_mapped
        if not ip.is_global:  # bloque localhost, réseaux privés, métadonnées cloud...
            raise ValueError("Adresse non autorisée.")
    return url


# ---------- messages d'erreur ----------
class _Logger:
    def __init__(self):
        self.errors: list[str] = []

    def debug(self, msg): pass
    def info(self, msg): pass
    def warning(self, msg): pass

    def error(self, msg):
        self.errors.append(_ANSI.sub("", str(msg)))


def friendly_error(msg: str) -> str:
    msg = _ANSI.sub("", msg or "").replace("ERROR: ", "").strip()
    low = msg.lower()
    if "confirm you" in low and "bot" in low or "sign in" in low:
        msg += " — Le site demande une connexion (anti-bot). Fournissez un fichier cookies.txt via la variable COOKIES_FILE."
    elif "ffmpeg" in low and ("not found" in low or "not installed" in low):
        msg += " — ffmpeg n'est pas installé ou introuvable dans le PATH."
    elif "javascript runtime" in low or "challenge" in low:
        msg += " — Installez deno (runtime JavaScript requis par yt-dlp pour YouTube)."
    return msg[:500] or "Erreur inconnue."


def _cookie_args() -> list[str]:
    return ["--cookies", config.COOKIES_FILE] if config.COOKIES_FILE else []


# ---------- analyse ----------
def extract_info(url: str, playlist: bool) -> dict:
    argv = ["--ignore-config", "--no-warnings", "--no-colors", "--socket-timeout", "20",
            "--yes-playlist" if playlist else "--no-playlist", "--flat-playlist", *_cookie_args()]
    logger = _Logger()
    opts = parse_options(argv).ydl_opts
    # ignoreerrors=False : une erreur d'extraction doit lever une exception, pas renvoyer None
    opts.update(quiet=True, skip_download=True, ignoreerrors=False, logger=logger)
    try:
        with YoutubeDL(opts) as ydl:
            raw = ydl.extract_info(url, download=False)
            info = ydl.sanitize_info(raw) if raw else None
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(friendly_error(logger.errors[-1] if logger.errors else str(e))) from e
    if not info:
        raise RuntimeError(friendly_error(logger.errors[-1] if logger.errors else
                                          "Impossible d'analyser cette URL."))
    is_playlist = info.get("_type") == "playlist"
    entries = [e for e in (info.get("entries") or []) if e]
    first = entries[0] if entries else {}
    formats = info.get("formats") or []
    heights = sorted({f["height"] for f in formats
                      if f.get("height") and f.get("vcodec") not in (None, "none")}, reverse=True)
    subs = sorted(set((info.get("subtitles") or {}).keys())
                  | set((info.get("automatic_captions") or {}).keys()))[:60]
    thumb = info.get("thumbnail") or first.get("thumbnail")
    if not thumb:
        thumbs = info.get("thumbnails") or first.get("thumbnails") or []
        thumb = thumbs[-1].get("url") if thumbs else None
    return {
        "title": info.get("title") or "Sans titre",
        "uploader": info.get("uploader") or info.get("channel") or first.get("uploader"),
        "duration": info.get("duration"),
        "thumbnail": thumb if thumb and thumb.startswith("https://") else None,
        "is_playlist": is_playlist,
        "playlist_count": (info.get("playlist_count") or len(entries)) if is_playlist else 1,
        "heights": heights,
        "subtitle_langs": subs,
        "extractor": info.get("extractor_key"),
    }


# ---------- téléchargement ----------
def build_argv(p: dict, out_dir) -> list[str]:
    a = ["--ignore-config", "--no-colors", "--newline", "--windows-filenames", "--no-mtime",
         "-o", str(out_dir / "%(title).150B [%(id)s].%(ext)s"),
         "--socket-timeout", "20", "--retries", "5", "--fragment-retries", "5",
         "--concurrent-fragments", "4", "--embed-metadata", *_cookie_args()]
    if config.MAX_FILESIZE:
        a += ["--max-filesize", config.MAX_FILESIZE]
    if p["playlist"]:
        a += ["--yes-playlist", "--ignore-errors", "--max-downloads", str(config.MAX_PLAYLIST_ITEMS)]
        if p.get("playlist_items"):
            a += ["--playlist-items", p["playlist_items"]]
    else:
        a += ["--no-playlist"]
    if p["sponsorblock"]:
        a += ["--sponsorblock-remove", "sponsor,selfpromo,interaction"]

    if p["mode"] == "audio":
        a += ["-x", "--audio-format", p["audio_format"]]
        if p["audio_format"] in ("mp3", "m4a", "opus", "aac"):
            a += ["--audio-quality", "0" if p["audio_bitrate"] == "best" else f"{p['audio_bitrate']}K"]
        if p["embed_thumbnail"] and p["audio_format"] != "wav":
            a += ["--embed-thumbnail"]
    else:
        h = p["quality"]
        sel = "bv*+ba/b" if h == "best" else f"bv*[height<={h}]+ba/b[height<={h}]"
        a += ["-f", sel, "--merge-output-format", p["container"]]
        a += ["-S", "res,vcodec:h264,acodec:m4a" if p["container"] == "mp4" else "res"]
        if p["embed_thumbnail"] and p["container"] != "webm":
            a += ["--embed-thumbnail"]
        if p["subtitles"]:
            a += ["--write-subs", "--write-auto-subs", "--sub-langs", p["sub_langs"], "--embed-subs"]
    return a


def submit(job_id: str, url: str, params: dict) -> None:
    _cancel_flags[job_id] = threading.Event()
    _executor.submit(_run_job, job_id, url, params)


def cancel(job_id: str) -> None:
    ev = _cancel_flags.get(job_id)
    if ev:
        ev.set()


def remove_files(job_id: str) -> None:
    shutil.rmtree(config.DOWNLOAD_DIR / job_id, ignore_errors=True)


def _run_job(job_id: str, url: str, p: dict) -> None:
    cancel_ev = _cancel_flags.setdefault(job_id, threading.Event())
    out_dir = config.DOWNLOAD_DIR / job_id
    logger = _Logger()
    st = {"t": 0.0, "idx": None, "files": [], "title": False}

    def check():
        if cancel_ev.is_set():
            raise DownloadCancelled()

    def progress_hook(d):
        check()
        info = d.get("info_dict") or {}
        if not st["title"] and info.get("title"):
            st["title"] = True
            db.update(job_id, title=info["title"])
        if d.get("status") != "downloading":
            return
        now = time.monotonic()
        if now - st["t"] < 0.5:
            return
        st["t"] = now
        idx = info.get("playlist_index") or 1
        if idx != st["idx"]:
            st["idx"], st["files"] = idx, []
        fn = d.get("filename")
        if fn not in st["files"]:
            st["files"].append(fn)
        n_streams = max(len(info.get("requested_formats") or []), 1)
        total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
        frac = (d.get("downloaded_bytes") or 0) / total if total else 0
        within = (st["files"].index(fn) + min(frac, 1)) / n_streams
        n_entries = info.get("n_entries") or 1
        pct = min(((idx - 1) + within) / n_entries * 100, 99)
        db.update(job_id, status="running", progress=round(pct, 1),
                  speed=d.get("speed"), eta=d.get("eta"))

    def pp_hook(d):
        check()
        if d.get("status") == "started":
            db.update(job_id, status="processing", speed=None, eta=None)

    try:
        check()
        out_dir.mkdir(parents=True, exist_ok=True)
        db.update(job_id, status="running", started_at=time.time())
        opts = parse_options(build_argv(p, out_dir)).ydl_opts
        opts.update(logger=logger, progress_hooks=[progress_hook], postprocessor_hooks=[pp_hook])
        try:
            with YoutubeDL(opts) as ydl:
                ydl.download([url])
        except MaxDownloadsReached:
            pass
        check()

        files = [f for f in out_dir.rglob("*") if f.is_file()
                 and f.suffix not in (".part", ".ytdl", ".temp", ".tmp")]
        if not files:
            raise RuntimeError(logger.errors[-1] if logger.errors else "Aucun fichier produit.")
        if len(files) > 1:
            title = (db.get(job_id) or {}).get("title") or "telechargement"
            safe = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", title)[:80] or "telechargement"
            bundle = out_dir / f"{safe}.zip"
            with zipfile.ZipFile(bundle, "w", zipfile.ZIP_STORED) as z:
                for f in files:
                    z.write(f, f.name)
                    f.unlink()
            final = bundle
        else:
            final = files[0]
        db.update(job_id, status="done", progress=100, speed=None, eta=None,
                  filename=final.relative_to(out_dir).as_posix(),
                  filesize=final.stat().st_size, finished_at=time.time())
    except DownloadCancelled:
        remove_files(job_id)
        db.update(job_id, status="cancelled", speed=None, eta=None, finished_at=time.time())
    except Exception as e:  # noqa: BLE001
        msg = friendly_error(str(e))
        remove_files(job_id)
        db.update(job_id, status="failed", error=msg, speed=None, eta=None, finished_at=time.time())
    finally:
        _cancel_flags.pop(job_id, None)


def cleanup_expired() -> None:
    cutoff = time.time() - config.FILE_TTL_HOURS * 3600
    for jid in db.finished_before(cutoff):
        remove_files(jid)
        db.delete(jid)
